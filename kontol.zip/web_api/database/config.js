module.exports = {
  tokens: "7467740518:AAFgqjLDnvMUZLBu1WfgLFDOrMiO2z2TpqQ",  // Ubah Jadi Token Bot Mu !!!
  owner: "7305534611", // Ubah Jadi Id Mu !!!
  port: "2002", // Ubah Jadi Port Panel Mu !!!
  ipvps: "152.42.226.186" // Ubah Jadi Ip Vps Mu !!!
};